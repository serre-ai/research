# ReasonGap Analysis Summary

## Dataset Overview

- **Instances**: 209,438
- **Tasks**: 11
- **Models**: 12
- **Conditions**: 9
- **Models evaluated**: claude-haiku-4-5-20251001, claude-opus-4-6, claude-sonnet-4-20250514, gpt-4o, gpt-4o-mini, meta-llama/llama-3.1-70b-instruct, meta-llama/llama-3.1-8b-instruct, mistralai/ministral-8b-2512, mistralai/mistral-small-24b-instruct-2501, o3, qwen/qwen-2.5-72b-instruct, qwen/qwen-2.5-7b-instruct

## Overall Accuracy by Condition

- **budget_cot**: 0.625
- **budget_cot_0.25x**: 0.278
- **budget_cot_0.5x**: 0.395
- **budget_cot_1.0x**: 0.496
- **budget_cot_2.0x**: 0.739
- **budget_cot_4.0x**: 0.788
- **direct**: 0.515
- **short_cot**: 0.749
- **tool_use**: 0.832

## Results by Gap Type

### Type 1: Sensitivity

- budget_cot: 0.604
- direct: 0.610
- short_cot: 0.743
- CoT lift (budget_cot): -0.006
- CoT lift (short_cot): +0.133

### Type 2: Depth

- budget_cot: 0.757
- budget_cot_0.25x: 0.444
- budget_cot_0.5x: 0.665
- budget_cot_1.0x: 0.861
- budget_cot_2.0x: 0.929
- budget_cot_4.0x: 0.937
- direct: 0.636
- short_cot: 0.849
- tool_use: 0.784
- CoT lift (budget_cot): +0.121
- CoT lift (budget_cot_0.25x): -0.192
- CoT lift (budget_cot_0.5x): +0.028
- CoT lift (budget_cot_1.0x): +0.225
- CoT lift (budget_cot_2.0x): +0.292
- CoT lift (budget_cot_4.0x): +0.300
- CoT lift (short_cot): +0.212
- CoT lift (tool_use): +0.148

### Type 3: Serial

- budget_cot: 0.557
- budget_cot_0.25x: 0.111
- budget_cot_0.5x: 0.124
- budget_cot_1.0x: 0.130
- budget_cot_2.0x: 0.549
- budget_cot_4.0x: 0.640
- direct: 0.290
- short_cot: 0.799
- CoT lift (budget_cot): +0.267
- CoT lift (budget_cot_0.25x): -0.179
- CoT lift (budget_cot_0.5x): -0.166
- CoT lift (budget_cot_1.0x): -0.160
- CoT lift (budget_cot_2.0x): +0.259
- CoT lift (budget_cot_4.0x): +0.349
- CoT lift (short_cot): +0.509

### Type 4: Algorithmic

- budget_cot: 0.326
- direct: 0.243
- short_cot: 0.436
- tool_use: 0.879
- CoT lift (budget_cot): +0.083
- CoT lift (short_cot): +0.193
- CoT lift (tool_use): +0.635

### Type 5: Intractability

- budget_cot: 0.380
- direct: 0.491
- short_cot: 0.526
- CoT lift (budget_cot): -0.111
- CoT lift (short_cot): +0.035

### Type 6: Architectural

- budget_cot: 0.805
- direct: 0.719
- short_cot: 0.874
- CoT lift (budget_cot): +0.086
- CoT lift (short_cot): +0.155

## Key Predictions Check

- **Types 2,3 (should benefit from CoT)**: CoT lift = +0.361
- **Types 5,6 (should NOT benefit from CoT)**: CoT lift = +0.113
